var class_object =
[
    [ "Object", "class_object.html#ae07c6d39eff0d3b7678ea6633303e05e", null ],
    [ "boundingBox", "class_object.html#a645bfb6559e1a37ab81154b3cef4acf6", null ],
    [ "computeBoundingBox", "class_object.html#a210c7bc59e0387b5dc8c0faa84d17b10", null ],
    [ "computeNormals", "class_object.html#a665bdf37558db4dfcbd3b4778fcf5fda", null ],
    [ "faces", "class_object.html#a5765f37f243288913fa1814713a18df8", null ],
    [ "readObj", "class_object.html#a25d76d1d24542d1b90b59c4c7a860f72", null ],
    [ "vertices", "class_object.html#af8636f03fb8c6eb072a6820c3975d55f", null ],
    [ "vertices", "class_object.html#a48e3cf44249d7021ef4bf1dabdd8d25a", null ]
];