var searchData=
[
  ['glwidget',['GLWidget',['../class_g_l_widget.html',1,'GLWidget'],['../class_g_l_widget.html#a694ea02df40223ca46f3dce4f84f1412',1,'GLWidget::GLWidget()']]]
];
