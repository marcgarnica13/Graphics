var searchData=
[
  ['scene',['scene',['../class_g_l_widget.html#a08384ff4052082681190f82a637bb6c4',1,'GLWidget']]],
  ['setpluginpath',['setPluginPath',['../class_g_l_widget.html#a2eb78d5af5250c92df4e8d812f3ef940',1,'GLWidget']]]
];
