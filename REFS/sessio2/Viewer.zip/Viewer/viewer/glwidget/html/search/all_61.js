var searchData=
[
  ['addobject',['addObject',['../class_g_l_widget.html#aecc0e823ab52cbb46a4eddc182688483',1,'GLWidget']]],
  ['addobjectfromfile',['addObjectFromFile',['../class_g_l_widget.html#a5e5acbbd12ce79e6eeedbddf79db78e2',1,'GLWidget']]]
];
