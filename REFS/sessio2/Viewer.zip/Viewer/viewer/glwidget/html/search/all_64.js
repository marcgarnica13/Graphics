var searchData=
[
  ['drawaxes',['drawAxes',['../class_g_l_widget.html#ada288c0ac7e1cfed83c2155f40a4689c',1,'GLWidget']]]
];
