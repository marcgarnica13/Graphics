var annotated =
[
    [ "BasicPlugin", "class_basic_plugin.html", "class_basic_plugin" ],
    [ "Box", "class_box.html", "class_box" ],
    [ "Camera", "class_camera.html", "class_camera" ],
    [ "Face", "class_face.html", "class_face" ],
    [ "GLWidget", "class_g_l_widget.html", "class_g_l_widget" ],
    [ "Object", "class_object.html", "class_object" ],
    [ "Point", "class_point.html", null ],
    [ "Scene", "class_scene.html", "class_scene" ],
    [ "Vector", "class_vector.html", null ],
    [ "Vertex", "class_vertex.html", "class_vertex" ]
];