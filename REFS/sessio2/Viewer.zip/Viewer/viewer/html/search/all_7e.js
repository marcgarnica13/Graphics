var searchData=
[
  ['_7ebasicplugin',['~BasicPlugin',['../class_basic_plugin.html#ab9e0831e4ab9a778dc9d6dc1fbc5a5b6',1,'BasicPlugin']]]
];
