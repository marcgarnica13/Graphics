var searchData=
[
  ['keypressevent',['keyPressEvent',['../class_basic_plugin.html#a2fcb8b510381bf1c86ade0a743d5e1e0',1,'BasicPlugin']]],
  ['keyreleaseevent',['keyReleaseEvent',['../class_basic_plugin.html#a5312d376c11073c3fb62151d73035faf',1,'BasicPlugin']]]
];
