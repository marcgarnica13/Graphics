var searchData=
[
  ['wheelevent',['wheelEvent',['../class_basic_plugin.html#a4543bfd6c513dc3c54f1db7356db3392',1,'BasicPlugin']]]
];
