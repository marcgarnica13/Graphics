var searchData=
[
  ['basicplugin',['BasicPlugin',['../class_basic_plugin.html',1,'']]],
  ['box',['Box',['../class_box.html',1,'']]]
];
