var searchData=
[
  ['onobjectadd',['onObjectAdd',['../class_basic_plugin.html#a085656edbb36bbd3ff78641ccf3a5b3b',1,'BasicPlugin']]],
  ['onpluginload',['onPluginLoad',['../class_basic_plugin.html#a9afb55a7d6d9af9315e790a2e35504c4',1,'BasicPlugin']]]
];
