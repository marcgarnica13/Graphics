var searchData=
[
  ['camera',['camera',['../class_basic_plugin.html#a12895f35432f5ca06c139df098780dd0',1,'BasicPlugin']]]
];
