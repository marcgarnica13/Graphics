var searchData=
[
  ['basicplugin',['BasicPlugin',['../class_basic_plugin.html#aa7fed24fcd31d2fbfee11b0aca708a19',1,'BasicPlugin']]]
];
