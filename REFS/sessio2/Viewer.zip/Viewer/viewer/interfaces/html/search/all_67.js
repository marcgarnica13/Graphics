var searchData=
[
  ['glwidget',['glwidget',['../class_basic_plugin.html#aab6f9ed1f456cf5bed7165b57bedd457',1,'BasicPlugin']]]
];
